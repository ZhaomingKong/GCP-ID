addpath('t_svd_lib');
addpath('lib')
%% test handling synthetic images
% Parameter settings
% ps = 8;maxK = 30;global_learning = 1;
% SR = 20;N_step = 8;modified = 1; divide_factor = 1.2;
% k = 1;
% disp(['this code test the t_svd with ps = ',num2str(ps),' maxK = ',num2str(maxK),' SR = ',num2str(SR),' N_step = ',num2str(N_step), ' global_learning = ',num2str(global_learning)]);
% 
% % Kodak
% addpath('Kodak');
% GT_Original_image_dir = 'Kodak';
% GT_fpath = fullfile(GT_Original_image_dir, '*.png');
% 
% GT_im_dir  = dir(GT_fpath);
% im_num = length(GT_im_dir);
% 
% sigma = 5; nSig_input = 25;
% mode = 'multi_channel'; test_method = 'GCP-CID';
% tau_best = 1.1;
% 
% disp(['tau_best = ',num2str(tau_best), ' noise_level = ', num2str(sigma), ' sigma_input = ', num2str(nSig_input),' test_method = ', test_method])
% 
% tau = tau_best;
% 
% for sigma = 10:10:60
%     k = 0; psnr_count = 0; ssim_count = 0;
%     for i = 1:5
%         origin_test = double(imread(fullfile(GT_Original_image_dir, GT_im_dir(i).name)) );
%         S = regexp(GT_im_dir(i).name, '\.', 'split');
% 
%         origin_test = origin_test/255;
%         noisy_test = origin_test + (sigma/255)*randn(size(origin_test));
% 
% %         noise_level_est = noise_est(noisy_test, tau);
% %         nSig_input = noise_level_est;
% %         disp('-------------------------------------------------------');
%         nSig_input = 25;
% 
%         tic
% 
%         [im_denoised, ~, ~] = GCP_CID_color_image(single(noisy_test),single(origin_test),ps,SR,nSig_input/255,maxK,N_step,modified,tau, global_learning, divide_factor);
% 
%         % calculate objective   index
%         [psnr_h, im_ssim, FSIM_img] = cal_img_metrics(noisy_test, im_denoised);
% 
%         time = toc;
% 
%         disp([num2str(time),' ',num2str(i),' ',num2str(nSig_input),' ',num2str(psnr_h),' ',num2str(im_ssim)]);
%         psnr_count = psnr_count + psnr_h;
%         ssim_count = ssim_count + im_ssim;
%         k = k + 1;
%         psnr_all(k) = psnr_h;
%         ssim_all(k) = im_ssim;
% 
%     end
% 
%     disp(['tau = ', num2str(tau), ' sigma = ',num2str(sigma),' maxK = ',num2str(maxK),' psnr_average = ',num2str(psnr_count/k), ' ssim_average = ',num2str(ssim_count/k)]);
%     disp('-------------------------------------------------------');
%     disp('-------------------------------------------------------');
%     disp([num2str(psnr_all)])
%     disp([num2str(ssim_all)])
%     disp('********************************************************')
%     disp('********************************************************')
% 
% end

%% Test handling real-world images
% CC15
addpath('CCImages');
GT_Original_image_dir = 'CCImages/CC15/';
GT_fpath = fullfile(GT_Original_image_dir, '*mean.png');
TT_Original_image_dir = 'CCImages/CC15/';
TT_fpath = fullfile(TT_Original_image_dir, '*real.png');

% CC60
% GT_Original_image_dir = 'CCImages/CC_60MeanImage/';
% GT_fpath = fullfile(GT_Original_image_dir, '*.png');
% TT_Original_image_dir = 'CCImages/CC_60NoisyImage/';
% TT_fpath = fullfile(TT_Original_image_dir, '*.png');

% PolyU
% data_folder = 'PolyU';
% GT_Original_image_dir = data_folder;
% TT_Original_image_dir = data_folder;
% addpath(data_folder);
% img_path = data_folder;
% fpath = fullfile(img_path, '*.JPG');
% all_name = dir(fpath);
% TT_fpath = fullfile(img_path, '*real.JPG');
% GT_fpath = fullfile(img_path, '*mean.JPG');

% HighISO_Cropped
% addpath('HighISO_Cropped');
% GT_Original_image_dir = 'HighISO_Cropped/';
% GT_fpath = fullfile(GT_Original_image_dir, '*clean.png');
% TT_Original_image_dir = 'HighISO_Cropped/';
% TT_fpath = fullfile(TT_Original_image_dir, '*noisy.png');

GT_im_dir  = dir(GT_fpath);
TT_im_dir  = dir(TT_fpath);
im_num = length(TT_im_dir);

% Parameter setting
ps = 8;maxK = 30; global_learning = 1; divide_factor = 1.2;
SR = 20;N_step = 4;modified = 1;
tau = 1.1;
disp(['tau = ',num2str(tau)])

k = 0; psnr_count = 0; ssim_count = 0;test_method = 'GCP-CID';
disp(['use_test method: ',test_method])

% Start denoising
for i = 1:im_num

    disp('*******************************************************************');
    origin_test = double(imread(fullfile(GT_Original_image_dir, GT_im_dir(i).name)) );
    S = regexp(GT_im_dir(i).name, '\.', 'split');
    fprintf('%s :\n', GT_im_dir(i).name);
    noisy_test = double( imread(fullfile(TT_Original_image_dir, TT_im_dir(i).name)) );

%     noise_level_est = noise_est(noisy_test, tau);
%     nSig_input = noise_level_est;
    nSig_input = 25;

    tic

    [im_denoised, ~, ~] = GCP_CID_color_image(single(noisy_test), single(origin_test), ps, SR, nSig_input, maxK, N_step, modified, tau, global_learning, divide_factor);

    time = toc;

    % calculate objective   index
    [psnr_h, im_ssim, FSIM_img] = cal_img_metrics(origin_test/255, im_denoised/255);

    disp([num2str(time),' num_img: ',num2str(i),' sigma_est ',num2str(nSig_input),' ',num2str(psnr_h),' ',num2str(im_ssim)]);
    psnr_count = psnr_count + psnr_h;
    ssim_count = ssim_count + im_ssim;
    k = k + 1;

end

disp(['sigma =  estimate',' maxK = ',num2str(maxK),' psnr_average = ',num2str(psnr_count/k), ' ssim_average = ',num2str(ssim_count/k)]);
disp('-------------------------------------------------------');
disp('-------------------------------------------------------');

%% Test SIDD
% -------------------------------------------------------------------------
% Author: Abdelrahman Abdelhamed, York University
% kamel@eecs.yorku.ca
% https://www.eecs.yorku.ca/~kamel/
% -------------------------------------------------------------------------
% Reference: Abdelrahman Abdelhamed, Lin S., Brown M. S.
% "A High-Quality Denoising Dataset for Smartphone Cameras",
% IEEE Computer Vision and Pattern Recognition (CVPR'18), June 2018.
% -------------------------------------------------------------------------

% Add path (You need to download the SIDD dataset from the official website, and put them in the SIDD folder)
% data_folder = 'SIDD';
% submitDir = 'Test_set';
% Val_Dir = 'Validation_set';
% cur_folder = pwd;
% 
% % Load data
% load(fullfile(data_folder, 'BenchmarkNoisyBlocksSrgb.mat'));
% load(fullfile(data_folder, 'ValidationGtBlocksSrgb.mat'));
% load(fullfile(data_folder, 'ValidationNoisyBlocksSrgb.mat'));
% Test_data = BenchmarkNoisyBlocksSrgb;
% Val_GT_data = ValidationGtBlocksSrgb;
% Val_Noisy_data = ValidationNoisyBlocksSrgb;
% 
% % Some optional, yet useful, data to include, feel free to put your data
% OptionalData.MethodName = 'GCP-CID'; %
% method = OptionalData.MethodName;
% 
% 
% % Parameter setting
% disp('--------------------------------------------------------------')
% disp(['denoising_method: ',num2str(method)])
% ps = 8;maxK = 30;global_learning = 1; noise_est_func = 1;
% SR = 20; N_step = 4;modified = 1; tau = 1.1; divide_factor = 1.2;
% disp([' ps: ', num2str(ps), ' maxK: ',num2str(maxK),  ' N_step: ',num2str(N_step), ' noise_est: ',num2str(noise_est_func)])
% disp([' SR: ', num2str(SR), ' tau: ',num2str(tau),  ' divide_factor: ',num2str(divide_factor), ' global_learning: ',num2str(global_learning)])
% disp('--------------------------------------------------------------')
% 
% [N_imgs, N_blocks, H, W, C] = size(Test_data);
% DenoisedBlocksSrgb = cell(N_imgs, N_blocks);
% 
% % modelSigma = best_sigma;
% elapsed_time = 0;  psnr_count = 0; ssim_count = 0;
% 
% for i = 1:N_imgs
%     psnr_i = 0;ssim_i = 0;
%     for b = 1:N_blocks
% 
%         % read current image of validation set
%         %         origin_test = single(squeeze(Val_GT_data(i,b,:,:,:)));
%         %         noisy_test = single(squeeze(Val_Noisy_data(i,b,:,:,:)));
% 
%         % read current image of test set
%         noisy_test = single(squeeze(Test_data(i,b,:,:,:)));
%         origin_test = noisy_test + 0.08;
% 
%         if(noise_est_func == 1)
%             noise_level_est = noise_est(noisy_test, tau);
%             modelSigma = noise_level_est;
%         else
%             modelSigma = 85;
%         end
% 
%         tic
% 
%         [Denoised, ~, ~] = GCP_CID_color_image(single(noisy_test),single(origin_test),ps,SR,modelSigma,maxK,N_step,modified,tau, global_learning, divide_factor);
% 
%         % calculate the PSNR and SSIM
%         [PSNR_denoised, SSIM_denoised] = calculate_index(origin_test/255, Denoised/255);
% 
%         psnr_count = psnr_count + PSNR_denoised;
%         ssim_count = ssim_count + SSIM_denoised;
%         
%         psnr_i = psnr_i + PSNR_denoised;
%         ssim_i = ssim_i + SSIM_denoised;
% 
%         time = toc;
%         elapsed_time = elapsed_time + time;
% 
%         %         disp(['time = ',num2str(time), ' image_i = ',num2str(i), ' image_crop_b = ', num2str(b), ' input_noise_level = ',num2str(modelSigma), ' PSNR_denoised = ', num2str(PSNR_denoised), ' SSIM_denoised = ',num2str(SSIM_denoised)]);
%         disp(['time = ',num2str(time), ' image_i = ',num2str(i), ' image_crop_b = ', num2str(b), ' input_noise_level = ',num2str(modelSigma)]);
%         DenoisedBlocksSrgb{i, b} = uint8(Denoised);
% 
%         cd(submitDir)
%         write_name = strcat('GCP-CID',num2str(i),'_',num2str(b),'_sigma_',num2str(floor(modelSigma)),'.png');
%         imwrite(uint8(Denoised), write_name);
%         write_name = strcat('noisy_img',num2str(i),'_',num2str(b),'.png');
%         imwrite(uint8(noisy_test), write_name);
%         write_name = strcat('clean_img',num2str(i),'_',num2str(b),'.png');
%         imwrite(uint8(origin_test), write_name);
%         cd(cur_folder)
% 
%     end
% 
%     disp('-------------------------------------------------')
%     disp(['psnr_count and ssim_count for ',num2str(i), ' is: ', num2str(psnr_i/b), ' ',num2str(ssim_i/b)])
%     disp('-------------------------------------------------')
% 
% end
% 
% disp(['modelSigma =',num2str(modelSigma),' psnr_avg = ',num2str(psnr_count/(i*b)),' ssim_avg = ',num2str(ssim_count/(i*b))]);
% 
% TimeMPSrgb = 0;
% 
% fprintf('Saving resutls...\n');
% save(fullfile(submitDir, 'SubmitSrgb.mat'), 'DenoisedBlocksSrgb', ...
%     'TimeMPSrgb', 'OptionalData', '-v7.3');
% fprintf('Done!\n');

%% Test DnD dataset

% cur_folder = pwd;
% data_folder = 'DnD';
% output_folder = 'Denoised\DnD';
% infos = load(fullfile(data_folder, 'info.mat'));
% info = infos.info;
% 
% % % Some optional, yet useful, data to include, feel free to put your data
% method = 'GCP-CID'; 
% 
% % Parameter setting
% disp('--------------------------------------------------------------')
% disp(['denoising_method: ',num2str(method)])
% ps = 8;maxK = 30;global_learning = 1; noise_est_func = 1;
% SR = 20; N_step = 4;modified = 1; tau = 1.1; divide_factor = 1.2;
% disp([' ps: ', num2str(ps), ' maxK: ',num2str(maxK),  ' N_step: ',num2str(N_step), ' noise_est: ',num2str(noise_est_func)])
% disp([' SR: ', num2str(SR), ' tau: ',num2str(tau),  ' divide_factor: ',num2str(divide_factor), ' global_learning: ',num2str(global_learning)])
% disp('--------------------------------------------------------------')
% 
% if(noise_est_func == 1)
%     output_folder = 'D:\Code\denoise\Color_image_denoising\Traditional_methods\Result_images\CMSt-SVD_RGGB\DnD\noise_est';
% end
% 
% N_imgs = 50; N_blocks = 20;
% % iterate over images
% for i=1:50
%     img = load(fullfile(data_folder, 'images_srgb', sprintf('%04d.mat', i)));
%     Inoisy = img.InoisySRGB;
%     
%     % iterate over bounding boxes
%     Idenoised_crop_bbs = cell(1,N_blocks);
%     
%     for b=1:20
%         bb = info(i).boundingboxes(b,:);
%         Inoisy_crop = Inoisy(bb(1):bb(3), bb(2):bb(4), :);
%         nlf = info(i).nlf;
%         
%         nlf.sigma = info(i).sigma_srgb(b);
%         noisy_test = Inoisy_crop;
%         origin_test = noisy_test + 0.08;
%         
%         if noise_est_func == 0
%             % Parameter setting3
%             if(nlf.sigma<=0.025)
%                 input_sigma = 10;
%             elseif(nlf.sigma<=0.05)
%                 %             input_sigma = nlf.sigma*255*1.5;
%                 input_sigma = 25;
%             end
%             
%             if(nlf.sigma>0.05 && nlf.sigma<0.08)
%                 input_sigma = 50;
%             end
%             
%             if(nlf.sigma>=0.08)
%                 input_sigma = nlf.sigma*255*6;
%             end
%             % Parameter setting3
%             
%         else
%             noise_level_est = noise_est_DnD(noisy_test*255, tau);
%             input_sigma = noise_level_est;
%         end
%         
%         disp(['image_i = ',num2str(i), ' image_crop_b = ', num2str(b),' noise_level = ',num2str(nlf.sigma), ' input_noise_level = ',num2str(input_sigma)])
%         
%         [Denoised, ~, ~] = GCP_CID_color_image(single(noisy_test),single(origin_test),ps,SR,modelSigma,maxK,N_step,modified,tau, global_learning, divide_factor);
%         
%         Idenoised_crop_bbs{b} = single(Denoised)/255;
%         
%         cd(output_folder)
%         write_name = strcat('CMStSVD_RGGB_img_','noise_est_',num2str(noise_est_func),'_',num2str(i),'_',num2str(b),'_sigma_',num2str(floor(input_sigma)),'.png');
%         imwrite(uint8(Denoised), write_name);
%         cd(cur_folder)
%         
%     end
%     
%     for b=1:20
%         Idenoised_crop = Idenoised_crop_bbs{b};
%         save(fullfile(output_folder, sprintf('%04d_%02d.mat', i, b)), 'Idenoised_crop');
%     end
%     
%     fprintf('Image %d/%d done\n', i,50);
% end


% Other functions
function noise_level_est = noise_est(noisy_test, tau) %% For SIDD

ps = 8;maxK = 30;global_learning = 1;
SR = 20;N_step = 16;modified = 1;
k = 0; origin_test = noisy_test + 0.18;

% Perform pre-filtering to determine the approximate noise range/ The
% prefiltering function can be any method (FFDNet maybe)
[im_denoised, ~, ~] = color_global_tSVD(single(noisy_test),single(origin_test),ps,SR,25,maxK,12,modified,tau);
[psnr_prefiltering, ~, ~] = cal_img_metrics(noisy_test/255, im_denoised/255);
if(psnr_prefiltering > 45)
    stop_criteria = 1.2;
    sigma_start = 5; sigma_end = 8;
    sigma_step = 1;
elseif(psnr_prefiltering>36 && psnr_prefiltering<=45)
    stop_criteria = 0.8;
    sigma_start = 10; sigma_end = 22;
    sigma_step = 4;
elseif(psnr_prefiltering>34 && psnr_prefiltering<=36)
    stop_criteria = 0.6;
    sigma_start = 19; sigma_end = 31;
    sigma_step = 4;
elseif(psnr_prefiltering>31 && psnr_prefiltering<=34)
    stop_criteria = 0.5;
    sigma_start = 20; sigma_end = 35;
    sigma_step = 5;
elseif(psnr_prefiltering>29 && psnr_prefiltering<=31)
    stop_criteria = 0.38;
    sigma_start = 35; sigma_end = 55;
    sigma_step = 5;
else
    stop_criteria = 0.19; % for the SIDD dataset
    %     stop_criteria = 0.05; % for the DnD dataset
    sigma_start = 55; sigma_end = 165;
    sigma_step = 10;
end

for sigma = sigma_start:sigma_step:sigma_end
    
    [im_denoised, ~, ~] = color_global_tSVD(single(noisy_test),single(origin_test),ps,SR,sigma,maxK,N_step,modified,tau);
    
    % calculate objective   index
    [psnr_h, im_ssim, FSIM_img] = cal_img_metrics(noisy_test/255, im_denoised/255);
    
    k = k + 1;
    psnr_all(k) = psnr_h;
    ssim_all(k) = im_ssim;
    
    if(k > 1)
        psnr_previous = psnr_all(k-1);
        psnr_current = psnr_all(k);
    else
        psnr_previous = 0;
        psnr_current = 10;
    end
    
    error = abs(psnr_current - psnr_previous);
    if(error < stop_criteria)
        break
    end
    
end

noise_level_est = sigma;
end

% function noise_level_est = noise_est_DnD(noisy_test, tau) %%  Setting 1
% (some times over-smooth)
%
% ps = 8;maxK = 30;global_learning = 1;
% SR = 20;N_step = 16;modified = 1;
% k = 0; origin_test = noisy_test + 0.18;
%
% % Perform pre-filtering to determine the approximate noise range/ The
% % prefiltering function can be any method (FFDNet maybe)
% [im_denoised, ~, ~] = color_global_tSVD(single(noisy_test),single(origin_test),ps,SR,25,maxK,12,modified,tau);
% [psnr_prefiltering, ~, ~] = cal_img_metrics(noisy_test/255, im_denoised/255);
% if(psnr_prefiltering > 45)
%     stop_criteria = 1.2;
%     sigma_start = 5; sigma_end = 8;
%     sigma_step = 1;
% elseif(psnr_prefiltering>36 && psnr_prefiltering<=45)
%     stop_criteria = 0.8;
%     sigma_start = 10; sigma_end = 22;
%     sigma_step = 4;
% elseif(psnr_prefiltering>34 && psnr_prefiltering<=36)
%     stop_criteria = 0.6;
%     sigma_start = 19; sigma_end = 31;
%     sigma_step = 4;
% elseif(psnr_prefiltering>31 && psnr_prefiltering<=34)
%     stop_criteria = 0.5;
%     sigma_start = 20; sigma_end = 35;
%     sigma_step = 5;
% elseif(psnr_prefiltering>29 && psnr_prefiltering<=31)
%     stop_criteria = 0.38;
%     sigma_start = 35; sigma_end = 55;
%     sigma_step = 5;
% else
%     stop_criteria = 0.038; % for the DnD dataset
%     sigma_start = 55; sigma_end = 165;
%     sigma_step = 10;
% end
%
%
%
% for sigma = sigma_start:sigma_step:sigma_end
%
%     [im_denoised, ~, ~] = color_global_tSVD(single(noisy_test),single(origin_test),ps,SR,sigma,maxK,N_step,modified,tau);
%
%     % calculate objective   index
%     [psnr_h, im_ssim, FSIM_img] = cal_img_metrics(noisy_test/255, im_denoised/255);
%
%     k = k + 1;
%     psnr_all(k) = psnr_h;
%     ssim_all(k) = im_ssim;
%
%     if(k > 1)
%         psnr_previous = psnr_all(k-1);
%         psnr_current = psnr_all(k);
%     else
%         psnr_previous = 0;
%         psnr_current = 10;
%     end
%
%     error = abs(psnr_current - psnr_previous);
%     if(error < stop_criteria)
%         break
%     end
%
% end
%
% noise_level_est = sigma;
% % disp(['prefiltering: ',num2str(psnr_prefiltering)])
% % disp(['noise_level_est: ',num2str(noise_level_est)])
% % disp(['psnr_all: ',num2str(psnr_all)])
% % disp(['ssim_all: ',num2str(ssim_all)])
%
% % disp('-------------------------------------------------------');
% % disp('-------------------------------------------------------');
%
%
% end

function noise_level_est = noise_est_DnD(noisy_test, tau) %%

ps = 8;maxK = 30;global_learning = 1;
SR = 20;N_step = 16;modified = 1;
k = 0; origin_test = noisy_test + 0.18;

% Perform pre-filtering to determine the approximate noise range/ The
% prefiltering function can be any method (FFDNet maybe)
[im_denoised, ~, ~] = color_global_tSVD(single(noisy_test),single(origin_test),ps,SR,25,maxK,12,modified,tau);
[psnr_prefiltering, ~, ~] = cal_img_metrics(noisy_test/255, im_denoised/255);
if(psnr_prefiltering > 45)
    stop_criteria = 1.2;
    sigma_start = 5; sigma_end = 8;
    sigma_step = 1;
elseif(psnr_prefiltering>38 && psnr_prefiltering<=45)
    stop_criteria = 0.8;
    sigma_start = 8; sigma_end = 16;
    sigma_step = 2;
elseif(psnr_prefiltering>35 && psnr_prefiltering<=38)
    stop_criteria = 0.68;
    sigma_start = 16; sigma_end = 26;
    sigma_step = 2;
elseif(psnr_prefiltering>31 && psnr_prefiltering<=35)
    stop_criteria = 0.59;
    sigma_start = 25; sigma_end = 35;
    sigma_step = 3;
elseif(psnr_prefiltering>27 && psnr_prefiltering<=31)
    stop_criteria = 0.51;
    sigma_start = 35; sigma_end = 55;
    sigma_step = 5;
else
    stop_criteria = 0.038; % for the DnD dataset
    sigma_start = 55; sigma_end = 165;
    sigma_step = 10;
end


for sigma = sigma_start:sigma_step:sigma_end
    
    [im_denoised, ~, ~] = color_global_tSVD(single(noisy_test),single(origin_test),ps,SR,sigma,maxK,N_step,modified,tau);
    
    % calculate objective   index
    [psnr_h, im_ssim, FSIM_img] = cal_img_metrics(noisy_test/255, im_denoised/255);
    
    k = k + 1;
    psnr_all(k) = psnr_h;
    ssim_all(k) = im_ssim;
    
    if(k > 1)
        psnr_previous = psnr_all(k-1);
        psnr_current = psnr_all(k);
    else
        psnr_previous = 0;
        psnr_current = 10;
    end
    
    error = abs(psnr_current - psnr_previous);
    if(error < stop_criteria)
        break
    end
    
end

noise_level_est = sigma;


end

function [psnr_img, ssim_img, FSIM_img] = cal_img_metrics(origin_test, noisy_test)

im2=single(noisy_test)*255;im=single(origin_test)*255; [H,W,D] = size(im);

mse = sum((im2(:)-im(:)).^2)/(H*W*D);

psnr_img = 10*log10(255*255/mse);

ssim_img = cal_ssim(im2,im,0,0);

[~,FSIM_img] = FeatureSIM(im2,im);

end

function [PSNR, SSIM] = calculate_index(denoised, clean)
PSNR = 10*log10(1/mean((clean(:)-double(denoised(:))).^2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate MMSIM value
K = [0.01 0.03];
window = fspecial('gaussian', 11, 1.5);
L = 1;
[mssim1, ~] = ssim_index(denoised(:,:,1),clean(:,:,1),K,window,L);
[mssim2, ~] = ssim_index(denoised(:,:,2),clean(:,:,2),K,window,L);
[mssim3, ~] = ssim_index(denoised(:,:,3),clean(:,:,3),K,window,L);
SSIM = (mssim1+mssim2+mssim3)/3.0;

end