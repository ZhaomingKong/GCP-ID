function [psnr, im_ssim, FSIMc] = cal_metrics(clean_img, noisy_img)

[H,W] = size(clean_img);

im2=single(clean_img);im=single(noisy_img);

mse = sum((im2(:)-im(:)).^2)/(H*W);

psnr = 10*log10(255*255/mse);

im_ssim = cal_ssim(im2,im,0,0);

[~,FSIMc] = FeatureSIM(im2,im);


end