%% test real dataset of 'A holistic approach to cross-channel image noise' (CC15 and CC60)
% % CC15
% addpath('CCImages');
% GT_Original_image_dir = 'CCImages/CC15/';
% GT_fpath = fullfile(GT_Original_image_dir, '*mean.png');
% TT_Original_image_dir = 'CCImages/CC15/';
% TT_fpath = fullfile(TT_Original_image_dir, '*real.png');

% % CC60
% GT_Original_image_dir = 'D:\Code\denoise\test_denoise\Guided-Image-Denoising-TIP2018-master\CCImages/CC_60MeanImage/';
% GT_fpath = fullfile(GT_Original_image_dir, '*.png');
% TT_Original_image_dir = 'D:\Code\denoise\test_denoise\Guided-Image-Denoising-TIP2018-master\CCImages/CC_60NoisyImage/';
% TT_fpath = fullfile(TT_Original_image_dir, '*.png');
%
% % PolyU
% data_folder = 'D:\Code\denoise\test_denoise\Guided-Image-Denoising-TIP2018-master\PolyUImages';
% GT_Original_image_dir = data_folder;
% TT_Original_image_dir = data_folder;
% addpath(data_folder);
% img_path = data_folder;
% fpath = fullfile(img_path, '*.JPG');
% all_name = dir(fpath);
% TT_fpath = fullfile(img_path, '*real.JPG');
% GT_fpath = fullfile(img_path, '*mean.JPG');

% % HighISO
% addpath('HighISO_Cropped');
% GT_Original_image_dir = 'HighISO_Cropped/';
% GT_fpath = fullfile(GT_Original_image_dir, '*clean.png');
% TT_Original_image_dir = 'HighISO_Cropped/';
% TT_fpath = fullfile(TT_Original_image_dir, '*noisy.png');
%
% GT_im_dir  = dir(GT_fpath);
% TT_im_dir  = dir(TT_fpath);
% im_num = length(TT_im_dir);
%
% k = 0; psnr_red_count = 0; psnr_green_count = 0; psnr_blue_count = 0;
% ssim_red_count = 0; ssim_green_count = 0;  ssim_blue_count = 0;
%
% for i = 1:im_num
%     origin_test = double(imread(fullfile(GT_Original_image_dir, GT_im_dir(i).name)));
%     S = regexp(GT_im_dir(i).name, '\.', 'split');
%     fprintf('%s :\n', GT_im_dir(i).name);
%     noisy_test = double(imread(fullfile(TT_Original_image_dir, TT_im_dir(i).name)));
%
%     for c = 1:3
%         origin_test_c = origin_test(:,:,c);
%         noisy_test_c = noisy_test(:,:,c);
%         [psnr_c, im_ssim_c, FSIM_c] = cal_metrics(origin_test_c, noisy_test_c);
%
%         if(c == 1)
%             psnr_red = psnr_c;
%             ssim_red = im_ssim_c;
%             psnr_red_count = psnr_red_count + psnr_red;
%             ssim_red_count = ssim_red_count + ssim_red;
%         elseif(c == 2)
%             psnr_green = psnr_c;
%             ssim_green = im_ssim_c;
%             psnr_green_count = psnr_green_count + psnr_green;
%             ssim_green_count = ssim_green_count + ssim_green;
%         elseif(c == 3)
%             psnr_blue = psnr_c;
%             ssim_blue = im_ssim_c;
%             psnr_blue_count = psnr_blue_count + psnr_blue;
%             ssim_blue_count = ssim_blue_count + ssim_blue;
%         end
%
%     end
%
%     disp(['img: ',num2str(i),' psnr_red: ',num2str(psnr_red),' psnr_green: ',num2str(psnr_green), ' psnr_blue: ',num2str(psnr_blue)]);
%     disp(['img: ',num2str(i),' ssim_red: ',num2str(ssim_red),' ssim_green: ',num2str(ssim_green), ' ssim_blue: ',num2str(ssim_blue)]);
%
%     k = k + 1;
% end
%
% disp(['psnr_red_average = ',num2str(psnr_red_count/k), ' psnr_green_average = ',num2str(psnr_green_count/k), ' psnr_blue_average = ',num2str(psnr_blue_count/k)]);
% disp(['ssim_red_average = ',num2str(ssim_red_count/k), ' ssim_green_average = ',num2str(ssim_green_count/k), ' ssim_blue_average = ',num2str(ssim_blue_count/k)]);
%
% disp('-------------------------------------------------------');
% disp('-------------------------------------------------------');

% % IOCV dataset
% camera_set = {'XIAOMI8','SONY_A6500','OPPO_R11s','IPHONE_6S','IPHONE_5S','CANON_600D','HUAWEI_honor6X','CANON_100D','Fujifilm_X100T', 'NIKON_D5300', 'IPHONE13', 'HUAWEI_Mate40Pro', 'CANON_5D_Mark4'};
% data_root_path = 'D:\Data\Color_Images\Other_Files\crop_chosen\';
% 
% for image_set = 1:length(camera_set)
%     
%     Camera_name = camera_set{image_set};
%     disp(['*******************',Camera_name,'**********************']);
%     data_folder = strcat(data_root_path, Camera_name);
%     addpath(data_folder);
%     img_path = data_folder;
%     fpath = fullfile(img_path, '*.bmp');
%     
%     all_name = dir(fpath);
%     noisy_name = dir(fullfile(img_path, '*noisy.bmp'));
%     clean_name = dir(fullfile(img_path, '*clean.bmp'));
%     im_num = length(noisy_name);
%     
%     k = 0; psnr_red_count = 0; psnr_green_count = 0; psnr_blue_count = 0;
%     ssim_red_count = 0; ssim_green_count = 0;  ssim_blue_count = 0;
%     
%     for i = 1:im_num
%         
%         origin_test = single(imread(clean_name(i).name));
%         noisy_test = single(imread(noisy_name(i).name));
%         
%         for c = 1:3
%             origin_test_c = origin_test(:,:,c);
%             noisy_test_c = noisy_test(:,:,c);
%             [psnr_c, im_ssim_c, FSIM_c] = cal_metrics(origin_test_c, noisy_test_c);
%             
%             if(c == 1)
%                 psnr_red = psnr_c;
%                 ssim_red = im_ssim_c;
%                 psnr_red_count = psnr_red_count + psnr_red;
%                 ssim_red_count = ssim_red_count + ssim_red;
%             elseif(c == 2)
%                 psnr_green = psnr_c;
%                 ssim_green = im_ssim_c;
%                 psnr_green_count = psnr_green_count + psnr_green;
%                 ssim_green_count = ssim_green_count + ssim_green;
%             elseif(c == 3)
%                 psnr_blue = psnr_c;
%                 ssim_blue = im_ssim_c;
%                 psnr_blue_count = psnr_blue_count + psnr_blue;
%                 ssim_blue_count = ssim_blue_count + ssim_blue;
%             end
%             
%         end
%         
%         disp(['img: ',num2str(i),' psnr_red: ',num2str(psnr_red),' psnr_green: ',num2str(psnr_green), ' psnr_blue: ',num2str(psnr_blue)]);
%         disp(['img: ',num2str(i),' ssim_red: ',num2str(ssim_red),' ssim_green: ',num2str(ssim_green), ' ssim_blue: ',num2str(ssim_blue)]);
%         
%         k = k + 1;
%     end
%     
%     disp(['*******************',Camera_name,'**********************']);
%     disp(['******************* Statistics **********************']);
%     
%     disp(['psnr_red_average = ',num2str(psnr_red_count/k), ' psnr_green_average = ',num2str(psnr_green_count/k), ' psnr_blue_average = ',num2str(psnr_blue_count/k)]);
%     disp(['ssim_red_average = ',num2str(ssim_red_count/k), ' ssim_green_average = ',num2str(ssim_green_count/k), ' ssim_blue_average = ',num2str(ssim_blue_count/k)]);
%     
%     disp('-------------------------------------------------------');
%     disp('-------------------------------------------------------');
%     
% end



%% SNR
% CC15
% addpath('CCImages');
% addpath('CCImages');
% GT_Original_image_dir = 'CCImages/CC15/';
% GT_fpath = fullfile(GT_Original_image_dir, '*mean.png');
% TT_Original_image_dir = 'CCImages/CC15/';
% TT_fpath = fullfile(TT_Original_image_dir, '*real.png');

% PolyU
% data_folder = 'D:\Code\denoise\test_denoise\Guided-Image-Denoising-TIP2018-master\PolyUImages';
% GT_Original_image_dir = data_folder;
% TT_Original_image_dir = data_folder;
% addpath(data_folder);
% img_path = data_folder;
% fpath = fullfile(img_path, '*.JPG');
% all_name = dir(fpath);
% TT_fpath = fullfile(img_path, '*real.JPG');
% GT_fpath = fullfile(img_path, '*mean.JPG');

% HighISO
% addpath('HighISO_Cropped');
% GT_Original_image_dir = 'HighISO_Cropped/';
% GT_fpath = fullfile(GT_Original_image_dir, '*clean.png');
% TT_Original_image_dir = 'HighISO_Cropped/';
% TT_fpath = fullfile(TT_Original_image_dir, '*noisy.png');

% GT_im_dir  = dir(GT_fpath);
% TT_im_dir  = dir(TT_fpath);
% im_num = length(TT_im_dir);
%
% k = 0;
% snr_red = zeros(10,1); snr_green = zeros(10,1); snr_blue = zeros(10,1);
%
% for i = 1:10
%     origin_test = double(imread(fullfile(GT_Original_image_dir, GT_im_dir(i).name)) );
%     S = regexp(GT_im_dir(i).name, '\.', 'split');
%     fprintf('%s :\n', GT_im_dir(i).name);
%     noisy_test = double( imread(fullfile(TT_Original_image_dir, TT_im_dir(i).name)) );
%
%     snr_red(i) = snr(origin_test(:,:,1), abs(origin_test(:,:,1) - noisy_test(:,:,1)));
%     snr_green(i) = snr(origin_test(:,:,2), abs(origin_test(:,:,2) - noisy_test(:,:,2)));
%     snr_blue(i) = snr(origin_test(:,:,3), abs(origin_test(:,:,3) - noisy_test(:,:,3)));
%
%     disp(['img: ',num2str(i),' snr_red: ',num2str(snr_red(i)),' snr_green: ',num2str(snr_green(i)), ' snr_blue: ',num2str(snr_blue(i))]);
%
% end
%
% disp('-------------------------------------------------------');
%
% disp(['snr_red_average = ',num2str(mean(snr_red)), ' snr_green_average = ',num2str(mean(snr_green)), ' snr_blue_average = ',num2str(mean(snr_blue))]);
%
% disp('-------------------------------------------------------');

% plot corresponding bar graph
% bar1(:,1) = snr_red;
% bar1(:,2) = snr_green;
% bar1(:,3) = snr_blue;
%
% GO = bar(bar1,1,'EdgeColor','Black');
% GO(1).FaceColor = 'Red';
% GO(2).FaceColor = 'Green';
% GO(3).FaceColor = 'Blue';


% IOCV dataset
camera_set = {'XIAOMI8','SONY_A6500','OPPO_R11s','IPHONE_6S','IPHONE_5S','CANON_600D','HUAWEI_honor6X','CANON_100D','Fujifilm_X100T', 'NIKON_D5300', 'IPHONE13', 'HUAWEI_Mate40Pro', 'CANON_5D_Mark4'};
data_root_path = 'D:\Data\Color_Images\Other_Files\crop_chosen\';

for image_set = 1:length(camera_set)
    
    Camera_name = camera_set{image_set};
    disp(['*******************',Camera_name,'**********************']);
    data_folder = strcat(data_root_path, Camera_name);
    addpath(data_folder);
    img_path = data_folder;
    fpath = fullfile(img_path, '*.bmp');
    
    all_name = dir(fpath);
    noisy_name = dir(fullfile(img_path, '*noisy.bmp'));
    clean_name = dir(fullfile(img_path, '*clean.bmp'));
    im_num = length(noisy_name);
    
    k = 0; snr_red = zeros(im_num,1); snr_green = zeros(im_num,1); snr_blue = zeros(im_num,1);
    
    for i = 1:im_num
        
        origin_test = single(imread(clean_name(i).name));
        noisy_test = single(imread(noisy_name(i).name));
        
        snr_red(i) = snr(origin_test(:,:,1), abs(origin_test(:,:,1) - noisy_test(:,:,1)));
        snr_green(i) = snr(origin_test(:,:,2), abs(origin_test(:,:,2) - noisy_test(:,:,2)));
        snr_blue(i) = snr(origin_test(:,:,3), abs(origin_test(:,:,3) - noisy_test(:,:,3)));
        
        disp(['img: ',num2str(i),' snr_red: ',num2str(snr_red(i)),' snr_green: ',num2str(snr_green(i)), ' snr_blue: ',num2str(snr_blue(i))]);
                
        k = k + 1;
    end
    
    disp(['*******************',Camera_name,'**********************']);
    disp(['******************* Statistics **********************']);
    
    disp(['snr_red_average = ',num2str(mean(snr_red)), ' snr_green_average = ',num2str(mean(snr_green)), ' snr_blue_average = ',num2str(mean(snr_blue))]);

    disp('-------------------------------------------------------');
    disp('-------------------------------------------------------');
    
end

%% SIDD dataset
% Add path
% data_folder = 'SIDD';
% cur_folder = pwd;
%
% % Load data
% load(fullfile(data_folder, 'BenchmarkNoisyBlocksSrgb.mat'));
% load(fullfile(data_folder, 'ValidationGtBlocksSrgb.mat'));
% load(fullfile(data_folder, 'ValidationNoisyBlocksSrgb.mat'));
% Test_data = BenchmarkNoisyBlocksSrgb;
% Val_GT_data = ValidationGtBlocksSrgb;
% Val_Noisy_data = ValidationNoisyBlocksSrgb;
%
% [N_imgs, N_blocks, H, W, C] = size(Test_data);
% snr_red = zeros(N_imgs, N_blocks);
% snr_green = zeros(N_imgs, N_blocks);
% snr_blue = zeros(N_imgs, N_blocks);
%
% for i = 1:N_imgs
%     psnr_i = 0;ssim_i = 0;
%     for b = 1:N_blocks
%
%         origin_test = single(squeeze(Val_GT_data(i,b,:,:,:)))/255;
%         noisy_test = single(squeeze(Val_Noisy_data(i,b,:,:,:)))/255;
%
%         snr_red(i,b) = snr(origin_test(:,:,1), abs(origin_test(:,:,1) - noisy_test(:,:,1)));
%         snr_green(i,b) = snr(origin_test(:,:,2), abs(origin_test(:,:,2) - noisy_test(:,:,2)));
%         snr_blue(i,b) = snr(origin_test(:,:,3), abs(origin_test(:,:,3) - noisy_test(:,:,3)));
%
%         disp(['img: ',num2str(i), '-',num2str(b),' snr_red: ',num2str(snr_red(i,b)),' snr_green: ',num2str(snr_green(i,b)), ' snr_blue: ',num2str(snr_blue(i,b))]);
%     end
% end
%
% disp('-------------------------------------------------------');
%
% disp(['snr_red_average = ',num2str(mean(snr_red(:))), ' snr_green_average = ',num2str(mean(snr_green(:))), ' snr_blue_average = ',num2str(mean(snr_blue(:)))]);
%
% disp('-------------------------------------------------------');